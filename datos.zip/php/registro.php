<?php

$getJSON = file_get_contents('php://input');

$dataJson = json_decode($getJSON);


$correo = $dataJson->{'correo'};
$contrasena = $dataJson->{'contrasena'};

/*

 echo $getJSON;
*/

//$mysqli = new mysqli("localhost", "root", "", "mulb"); // local

$mysqli = new mysqli("sql301.infinityfree.com", "if0_38853035", "TT3bvox7gT", "if0_38853035_mulb"); // remota


/*if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
} else {
    echo "Connected successfully";
}*/

$sql = "INSERT INTO `usuario` (`id`, `correo`, `contrasena`) VALUES (NULL, '".$correo."', '".$contrasena."');";

if ($mysqli->query($sql) === TRUE) {
    echo "ok";
} else {
    echo "porque?";
}



$mysqli->close();

?>